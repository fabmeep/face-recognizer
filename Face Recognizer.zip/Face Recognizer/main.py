# import the library needed
import cv2
import os
import math
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# make the model
classifier = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
face_recognizer = cv2.face.LBPHFaceRecognizer_create()

# make array to save face list and the class for the face list
face_list = []
face_class_list = []
# training path is as shown, which is Dataset/
train_path = 'Dataset/'

def train():
    for idx, class_path in enumerate(os.listdir(train_path)):
        for image_path in os.listdir(f'{train_path}{class_path}'):
            # making the full path to reach into each image path
            full_path = f'{train_path}{class_path}/{image_path}'
            # make it grayscale
            gray = cv2.imread(full_path, cv2.IMREAD_GRAYSCALE)
            # Apply bilateral filter, other filters makes the model worse, so we only apply bilateral filter
            filter=  cv2.bilateralFilter(gray,9,75,75)
            faces = classifier.detectMultiScale(filter, scaleFactor = 1.2, minNeighbors = 5)
            # if there is no face, just continue, and make a message that there's no face
            if len(faces) < 1:
                continue
            else:
                for face in faces:
                    x, y, w, h = face
                    face_image = filter[y:y+h, x:x+w]
                    face_list.append(face_image)
                    face_class_list.append(idx)     
    # split the dataset into train and testing, with the test size of 25%
    x_train, x_test, y_train, y_test = train_test_split(face_list, face_class_list, test_size=0.25, random_state=42)
    # train the model
    face_recognizer.train(x_train, np.array(y_train))
    # save the model
    face_recognizer.save('save_model.yml')
    print('Training Completed')

    # predict the test data
    y_pred = []
    for face in x_test:
        result, confidence = face_recognizer.predict(face)
        y_pred.append(result)
    # calculate the accuracy score
    accuracy = accuracy_score(y_test, y_pred)
    accuracy_percentage = 100 * accuracy
    print(f'Accuracy Score: {accuracy_percentage}%')    

    
def predict():
    # make sure that you have the saved model
    if not os.path.exists('save_model.yml'):
        print('Model not found')
        return
    else:
        face_recognizer.read('save_model.yml')
        # Ask for input: image path
        print('Input image absolute path to predict: ')
        image_path = input()
        
        # If path doesn't exist, print error message
        if not os.path.exists(image_path):
            print('Image not found')
            return
        else:
            # read image path and apply gray filter
            img = cv2.imread(image_path)
            gray = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            # Apply bilateral filter
            filter_img = cv2.bilateralFilter(gray, 9, 50, 50)
            
            # Detect faces
            faces = classifier.detectMultiScale(filter_img, scaleFactor=1.2, minNeighbors=5)
            
            # if theres no face
            if len(faces) < 1:
                print('No faces detected')
            else:
                for face in faces:
                    x, y, w, h = face
                    face_image = filter_img[y:y+h, x:x+w]
                    
                    # Recognize the face
                    result, confidence = face_recognizer.predict(face_image)
                    
                    # Draw rectangle around the face
                    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    
                    # Display recognized label and confidence
                    label = os.listdir(train_path)[result]
                    confidence = math.floor(confidence * 100) / 100
                    # make the confidence from 0 to 100% format
                    confidence = 100 - float(confidence)
                    text = f'{label}: {confidence}%'
                    cv2.putText(img, text, (x-50, y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                    
                # Display the result image
                cv2.imshow('result', img)
                cv2.waitKey(0)
                cv2.destroyAllWindows()


# make menu function where user can choose to train or recognize or exit
def menu():
    while True:
        print('Football Player Face Recognition')
        print('Choose the option: ')
        print('1. Train and Test Model')
        print('2. Predict Image')
        print('3. Exit')
        choice = int(input('>>'))
        if choice == 1:
            train()
            input('Press enter to continue')
        elif choice == 2:
            predict()
            input('Press enter to continue')
        elif choice == 3:
            exit()
        else:
            print('Invalid choice \n')

menu()